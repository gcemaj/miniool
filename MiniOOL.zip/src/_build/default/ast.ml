type indetifier = string ref;;

type expr = 
  | Integer of int
  | BinaryArithmeticOperator of (int -> int -> int) * expr * expr
  | UniaryAithmeticOperator of (int -> int) * expr
  | Variable of identifier

and bool_expr =
  | Bool of bool
  | BinaryIntegerComparatorExpr of (int -> int -> bool) * expr * expr
  | UnaryIntegerComparatorExpr of (int -> bool) * expr
  | BinaryBoolComparatorExpr of (bool -> bool -> bool) * bool_expr * bool_expr
  | UnaryBoolComparatprExpr of (bool -> bool) * bool_expr

and cmd = 
  | Declaration of identifier
  | Assigment of identifier * expr
  | IfThenElseControlFlow of bool_expr * cmd * cmd
  | IfThenControlFlow of bool_expr * cmd
  | WhileControlFlow of bool_expr * cmd

and cmds = cmd list

and program = cmds;;